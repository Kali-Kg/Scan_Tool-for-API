#!/usr/bin/env python3

import psutil

def get_mac_address():
    for iface, addrs in psutil.net_if_addrs().items():
        for addr in addrs:
            if addr.family == psutil.AF_LINK:  # MAC-адрес
                if addr.address and addr.address != "00:00:00:00:00:00":
                    return addr.address
    return None

print("MAC:", get_mac_address())
